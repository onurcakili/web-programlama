<?php


use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\FormController;
use App\Http\Controllers\DBController;
use App\Http\Controllers\ModelController;
use App\Http\Controllers\Requiest;
use App\Http\Controllers\PhotoController;
use App\Http\Controller\LoginController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});






/* CONTROLLERS */

Route::get("/Home",[HomeController::class,"Home"])->name("homePage");  //kütüphaneye eklemeyi unutma
Route::get("/Product",[ProductController::class,"Product"])->name("productPage");
Route::get("/Account",[AccountController::class,"Account"])->name("accountPage");
Route::get("/Form",[FormController::class,"Form"])->name("formPage");
Route::get("/Photo",[FormController::class,"Photo"])->name("photoPage");





/* MIDDLE WARE */

Route::middleware('formKontrol') -> post("/FormSonuc",[FormController::class,"FormSonuc"])->name("formSonucPage");



/* CRUD İSLEMLERİ */

Route::get("/ekle",[DBController::class,"ekle"]);
Route::get("/guncelle",[DBController::class,"guncelle"]);
Route::get("/sil",[DBController::class,"sil"]);
Route::get("/listele",[DBController::class,"listele"]);


/* MODEL ile crud işlemleri */

Route::get("/modelEkle",[ModelController::class,"modelEkle"]);
Route::get("/modelListele",[ModelController::class,"modelListele"]);
Route::get("/modelGuncelle",[ModelController::class,"modelGuncelle"]);
Route::get("/modelSil",[ModelController::class,"modelSil"]);



/* Account Route */

Route::get("/account",[AccountController::class,"index"]);
Route::post("/account",[AccountController::class,"ekle"])->name("account")->name("accountSonuc");


/* Photos Route */

Route::get('/photo', function () {
    return view('photo');
});

Route::post("/photo",[PhotoController::class,"photoUpload"])->name("photo");


/* Login Route */

