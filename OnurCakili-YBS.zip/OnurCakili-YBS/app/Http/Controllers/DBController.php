<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class DBController extends Controller
{
    public function ekle()
    {
        DB::table("hesap")->insert([
            "name"=>"Onur",
            "surname"=>"Cakili",
            "city"=>"Hatay",
            "gmail"=>"onurcakili@gmail.com"
        ]);
    }

    public function guncelle()
    {
        DB::table("hesap")->where("id",2)->update([
            "name"=>"Mehmet"
        ]);
    }


    public function sil()
    {
        DB::table("hesap")->where("id",1)->delete();
    }

    public function listele()
    {
        $veriler=DB::table("hesap")->get();

        foreach($veriler as $key => $hesap){
            echo $hesap->name. " " .$hesap->surname;
            echo "<br>";
        }
    }

}
