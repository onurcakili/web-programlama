<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PhotoController extends Controller
{
    public function photoUpload(Request $request)
    {
        $resimadi=rand(1,1000).".".$request->resim->getClientOriginalName();
        $yukle=$request->resim->move(public_path('images'),$resimadi);
        echo "Resim public/images klasorüne Başarıyla Yüklendi";
    }
}
