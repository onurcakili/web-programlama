<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Form Sayfası</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="https://tasarim.phpturkiye.net/assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- Third party plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="https://tasarim.phpturkiye.net/css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">




        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="{{route('homePage')}}">Pazar Vadisi</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="Home#about">Hakkımızda</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="{{route('productPage')}}">Ürünler</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="{{route('photo')}}">Fotoğraf Ekle</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="{{route('accountPage')}}">Üye Ol</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="{{route('formPage')}}">Form</a></li>
                        
                    </ul>
                </div>
            </div>
        </nav>


            

        <!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end"> <br> <br> <br>
                        <h2 class="text-uppercase text-white font-weight-bold">Ürün Listeleme (with Model) </h2>
                        <hr class="divider my-4" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">



                                <div class="content">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title"> Kategoriler</h4>
                                                </div>



                                                <div class="container-fluid p-0">
                <div class="row no-gutters">
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="https://tasarim.phpturkiye.net/assets/img/portfolio/fullsize/1.jpg">
                            <img class="img-fluid" src="https://tasarim.phpturkiye.net/assets/img/portfolio/thumbnails/1.jpg" alt="" />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">Özel Eşya</div>
                                <div class="project-name">Antika Eşya</div>
                            </div>
                        </a>



            </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="https://tasarim.phpturkiye.net/assets/img/portfolio/fullsize/2.jpg">
                            <img class="img-fluid" src="https://tasarim.phpturkiye.net/assets/img/portfolio/thumbnails/2.jpg" alt="" />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">Kitap ve Diğerleria</div>
                                <div class="project-name">Özel Eşya</div>
                            </div>
                        </a>
                    </div>



                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="https://tasarim.phpturkiye.net/assets/img/portfolio/fullsize/3.jpg">
                            <img class="img-fluid" src="https://tasarim.phpturkiye.net/assets/img/portfolio/thumbnails/3.jpg" alt="" />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">Fotoğraf Makinesi</div>
                                <div class="project-name">Teknolojik Eşya</div>
                            </div>
                        </a>
                    </div>




                    
                                                <div class="card-body">
                                                    <div class="table-responsive">
                                                        <table class="table">
                                                            <thead class=" text-primary">
                                                                <th>
                                                                    Ürün Adi
                                                                </th>
                                                                <th>
                                                                    Üretim Yeri
                                                                </th>
                                                                <th>
                                                                    Ürün Kategorisi
                                                                </th>
                                                                <th class="text-right">
                                                                    Fiyatı
                                                                </th>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        Dakota Rice
                                                                    </td>
                                                                    <td>
                                                                        Niger
                                                                    </td>
                                                                    <td>
                                                                        Oud-Turnhout
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $36,738
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Minerva Hooper
                                                                    </td>
                                                                    <td>
                                                                        Curaçao
                                                                    </td>
                                                                    <td>
                                                                        Sinaai-Waas
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $23,789
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Sage Rodriguez
                                                                    </td>
                                                                    <td>
                                                                        Netherlands
                                                                    </td>
                                                                    <td>
                                                                        Baileux
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $56,142
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Philip Chaney
                                                                    </td>
                                                                    <td>
                                                                        Korea, South
                                                                    </td>
                                                                    <td>
                                                                        Overland Park
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $38,735
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Doris Greene
                                                                    </td>
                                                                    <td>
                                                                        Malawi
                                                                    </td>
                                                                    <td>
                                                                        Feldkirchen in Kärnten
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $63,542
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Mason Porter
                                                                    </td>
                                                                    <td>
                                                                        Chile
                                                                    </td>
                                                                    <td>
                                                                        Gloucester
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $78,615
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Jon Porter
                                                                    </td>
                                                                    <td>
                                                                        Portugal
                                                                    </td>
                                                                    <td>
                                                                        Gloucester
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $98,615
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="card card-plain">
                                                <div class="card-header">
                                                    <h4 class="card-title"> Kategoriler </h4>
                                                    <p class="card-category"> Fotoğraf Ekleme Bölümünden buraya fotoğraf ekleyebilirsiniz.</p>
                                                </div>
                                                <div class="card-body">
                                                    <div class="table-responsive">
                                                        <table class="table">

                                                                    
                                                        
            



                                                        <div class="row no-gutters">
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="https://tasarim.phpturkiye.net/assets/img/portfolio/fullsize/1.jpg">
                            <img class="img-fluid" src="https://tasarim.phpturkiye.net/assets/img/portfolio/thumbnails/1.jpg" alt="" />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">Category</div>
                                <div class="project-name">Ankita Eşya</div>
                            </div>
                        </a>



            </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="https://tasarim.phpturkiye.net/assets/img/portfolio/fullsize/2.jpg">
                            <img class="img-fluid" src="https://tasarim.phpturkiye.net/assets/img/portfolio/thumbnails/2.jpg" alt="" />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">Category</div>
                                <div class="project-name">Kitap ve Diğerleri</div>
                            </div>
                        </a>
                    </div>



                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="https://tasarim.phpturkiye.net/assets/img/portfolio/fullsize/3.jpg">
                            <img class="img-fluid" src="https://tasarim.phpturkiye.net/assets/img/portfolio/thumbnails/3.jpg" alt="" />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">Category</div>
                                <div class="project-name">Teknolojik Eşya</div>
                            </div>
                        </a>
                    </div>



                                                            <thead class=" text-primary">
                                                                <th>
                                                                    Ürün Adi
                                                                </th>
                                                                <th>
                                                                    Üretim Yeri
                                                                </th>
                                                                <th>
                                                                    Ürün Kategorisi
                                                                </th>
                                                                <th class="text-right">
                                                                    Fiyatı
                                                                </th>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        Dakota Rice
                                                                    </td>
                                                                    <td>
                                                                        Niger
                                                                    </td>
                                                                    <td>
                                                                        Oud-Turnhout
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $36,738
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Minerva Hooper
                                                                    </td>
                                                                    <td>
                                                                        Curaçao
                                                                    </td>
                                                                    <td>
                                                                        Sinaai-Waas
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $23,789
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Sage Rodriguez
                                                                    </td>
                                                                    <td>
                                                                        Netherlands
                                                                    </td>
                                                                    <td>
                                                                        Baileux
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $56,142
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Philip Chaney
                                                                    </td>
                                                                    <td>
                                                                        Korea, South
                                                                    </td>
                                                                    <td>
                                                                        Overland Park
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $38,735
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Doris Greene
                                                                    </td>
                                                                    <td>
                                                                        Malawi
                                                                    </td>
                                                                    <td>
                                                                        Feldkirchen in Kärnten
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $63,542
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Mason Porter
                                                                    </td>
                                                                    <td>
                                                                        Chile
                                                                    </td>
                                                                    <td>
                                                                        Gloucester
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $78,615
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        Jon Porter
                                                                    </td>
                                                                    <td>
                                                                        Portugal
                                                                    </td>
                                                                    <td>
                                                                        Gloucester
                                                                    </td>
                                                                    <td class="text-right">
                                                                        $98,615
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        
                    </div>
                </div>
            </div>
        </header>

        


        









        
        
    </body>
</html>