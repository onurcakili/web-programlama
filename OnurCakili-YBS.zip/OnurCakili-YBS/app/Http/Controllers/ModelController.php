<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products;

class ModelController extends Controller
{
    public function modelListele()
    {
        $urun=Products::where("id",2)->first();

        echo $urun->urunadi;
    }


    public function modelEkle()
    {
        Products::create([
            "urunadi"=>"Samsung A23",
            "urunkategori"=>"Telefon",
            "urunfiyat"=>"1000"
        ]);
    }


    public function modelGuncelle()
    {
        Products::whereId(3)->update([
            "urunadi"=>"Xiamo TTS1",
            "urunkategori"=>"Telefon",
            "urunfiyat"=>"2000"
        ]);
    }

    public function modelSil()
    {
        Products::whereId(2)->delete();
        
    }

    
}
