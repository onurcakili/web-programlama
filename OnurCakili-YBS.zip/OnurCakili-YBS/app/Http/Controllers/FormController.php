<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormController extends Controller
{
    public function Form()
    {
    
        return view('form');
    }

    public function formSonuc(Request $request)
    {
        return $request->text;$_POST["text"];
    }
}
