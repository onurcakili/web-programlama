<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Form Sayfası</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="https://tasarim.phpturkiye.net/assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- Third party plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="https://tasarim.phpturkiye.net/css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">




        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="{{route('homePage')}}">Pazar Vadisi</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="Home#about">Hakkımızda</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="{{route('productPage')}}">Ürünler</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="{{route('photo')}}">Fotoğraf Ekle</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="{{route('accountPage')}}">Üye Ol</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="{{route('formPage')}}">Form</a></li>
                    </ul>
                </div>
            </div>
        </nav>




        <!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end">
                        <h1 class="text-uppercase text-white font-weight-bold">Form Sayfası</h1>
                        <hr class="divider my-4" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">

                        <p class="text-white-75 font-weight-light mb-5">Form Sayfasına Hoş Geldiniz</p>

                        <h7> 'yasak' Kelimesini kullanırsanız iletiniz GÖNDERİLMEZ. <br>  'MiddleWare' Yapısı Kullanılmıştır <br> Harici yazılarda iletinizi gönderebilirsiniz </h4>

                        <form action="{{ route('formSonucPage') }}" method="post">
                        @csrf

                        <textarea name="text" style="widht:400px; height:200px"> </textarea>  <br>
                        <input type="submit" name="ilet" value="Gönder">

                        </form>



                        
                    </div>
                </div>
            </div>
        </header>

        


        









        
        
    </body>
</html>