<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Requiest;
use App\Models\Accounts;


class AccountController extends Controller
{
    public function Account()
    {
    
        return view('account');
    }

   

    public function ekle(Requiest $hesap)
    {
        $name=$hesap->name;
        $surname=$hesap->surname;
        $city=$hesap->city;
        $gmail=$hesap->gmail;


        Accounts::create([
            "name"=>$name,
            "surname"=>$surname,
            "city"=>$city,
            "gmail"=>$gmail
        ]);

        echo "Bilgileriniz Veri Tabanına Kaydedilmiştir!";


    }
}
