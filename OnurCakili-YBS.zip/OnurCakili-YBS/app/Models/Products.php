<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    use HasFactory;
    protected $table="urunler";
    protected $fillable=["urunadi", "urunkategori", "urunfiyat", "created_at", "updated_at"];
}
